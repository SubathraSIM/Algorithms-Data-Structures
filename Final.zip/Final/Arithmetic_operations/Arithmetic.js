// Program 1 : Solving arithmetic operations

// Name: Subathra Sundarbabu
// Student id: 10263704
// Module code: CM2035
// Module name: Algorithms & Data Structures II
// Description: Calculate Arithemetic Postfix operations and prints out the sorted stack as well. 
//                              Sorted stack is only for display purpose and does not affect the calculations.
// Date: 22 June 2025

// /////////////////////////////
//  Sorting 1 : Bubble Sort  //
// ////////////////////////////
function bubble_sort(array) {
    // Copy of the array so the original calculation is not affected
    let sort = [...array];
    // For loop
    for (let i = 0; i < sort.length - 1; i++) {
        // Nested for loop to compare the numbers
        for (let j = 0; j < sort.length - i - 1; j++) {
            // If the current number is bigger than the next one, swap
            if (sort[j] > sort[j + 1]) {
                [sort[j], sort[j + 1]] = [sort[j + 1], sort[j]];
            }
        }
    }
    // Return the sorted array
    return sort;
}

/////////////////////////////////
// Sorting 2 : Insertion Sort //
////////////////////////////////

function insertion_sort(array) {
    // Copy of the array so the original calculation is not affected
    let sort = [...array];
    // For loop, start from the second number
    for (let i = 1; i < sort.length; i++) {
        // Store the current number
        let key = sort[i];

        // Compare with the number before it
        let j = i - 1;

        // Move numbers which are bigger than the key
        while (j >= 0 && sort[j] > key) {
            // Move the bigger number to the right
            sort[j + 1] = sort[j];
            // Move to the previous number
            j = j - 1;
        }
        // Put the key at the sorted position
        sort[j + 1] = key;
    }
    // Return the sorted array
    return sort;
}

//////////////////////////////
//  Sorting 3 : Merge Sort //
/////////////////////////////
function merge_sort(array) {
    // If the array has 0 or 1 number, it is sorted
    if (array.length <= 1) {
        return array;
    }

    // Find the middle index
    const mid = Math.floor(array.length / 2);

    // Sort the left half
    const small = merge_sort(array.slice(0, mid));

    // Sort the right half
    const big = merge_sort(array.slice(mid));

    // Merge the left and right half
    return merge(small, big);
}

// Merge the 2 sorted array into 1
function merge(small, big) {
    // Empty array to store the result
    let result = [];

    // Pointer
    let i = 0;

    // Pointer
    let j = 0;

    // Compare numbers until one array is completed
    while (i < small.length && j < big.length) {
        // If the current number in left is smaller, add it to result
        if (small[i] < big[j]) {
            // Move pointer forward
            result.push(small[i++]);
        } else {
            // Move pointer forward
            result.push(big[j++]);
        }
    }
    // Leftover numbers add to result
    return result.concat(small.slice(i)).concat(big.slice(j));
}

/////////////////////////////////
//    Sorting 4: Quick sort   //
////////////////////////////////
function quick_sort(array) {
    // If the array has 0 or 1 number, it is sorted
    if (array.length <= 1) {
        return array;
    }

    // Last number is pivot
    const pivot = array[array.length - 1];

    // empty array to store small values
    const small = [];

    // empty array to store big values
    const big = [];

    // For loop go into all numbers except the pivot
    for (let i = 0; i < array.length - 1; i++) {
        // If the current number is smaller than the pivot, put it in left
        if (array[i] < pivot) {
            small.push(array[i]);
        }
        // If the current number is bigger than the pivot, put it in right
        else {
            big.push(array[i]);
        }
    }
    // Sort and return the combined array, pivot in middle
    return [...quick_sort(small), pivot, ...quick_sort(big)];
}

//////////////////////////////////
//  Sorting 5: Selection sort  //
/////////////////////////////////
function selection_sort(array) {
    // Copy of the array so the original calculation is not affected
    let sort = [...array];
    
    // Loop thorugh each number in the array, expect the last one
    for (let i = 0; i < sort.length - 1; i++) {
        // Assume the current index is the smallest number
        let min = i;

        // Look for a smaller value
        for (let j = i + 1; j < sort.length; j++) {
            // If there is, remember the index
            if (sort[j] < sort[min]) {
                min = j;
            }
        }
        // If a smallest number is found, swap
        if (min !== i) {
            // Swap the numbers
            [sort[i], sort[min]] = [sort[min], sort[i]];
        }
    }
    // Return the sorted array
    return sort;
}

// Postfix evaluation
function Evaluation_Postfix(tokens, sorting_show, sort_algo) {
    // Stack to store the numbers
    let stack = [];

    // Go into each postfix expressions
    for (let token of tokens) {
        // If the token is a number
        if (!isNaN(token)) {
            // If the user wants details
            if (sorting_show){ 
                // Console log statement 
                console.log(`Token '${token}' is an operand.`);
            }
            // Push the number into the stack
            stack.push(Number(token));
        } 
        // If the token is operator
        else if (["+", "-", "*", "/"].includes(token)) {
            // If the user want details
            if (sorting_show) {
                // Console log statement
                console.log(`Token '${token}' is an operator.`);
                // Console log before stack
                console.log('\nBefore stack:         ', [...stack]);
                // Apply the sorting function
                const sorted = sort_algo([...stack]);
                // Console log the sorted stack
                console.log(`Before '${token}' operation, sorted stack:`, sorted);
            }

            // if less than 2 numbers to apply operator
            if (stack.length < 2) {
                // Console log statement error message
                console.log(`Error: Not enough operands for operator '${token}'`);
                return;
            }

            // Take the last 2 numbers from the stack
            const value_1 = stack.pop();
            const value_2 = stack.pop();
            let result;

            // Math operations for the different operators
            switch (token) {
                case '+': result = value_2 + value_1; break; // addition
                case '-': result = value_2 - value_1; break; // substraction
                case '*': result = value_2 * value_1; break; // multiplication
                case '/': result = value_2 / value_1; break; // division
            }

            // If the user wants details
            if (sorting_show) {
                // Console log statement
                console.log(`Calculation:          ${value_2} ${token} ${value_1} = ${result}\n`);
            }

            // Push result back to the stack
            stack.push(result);
        } 
        // If the token is not a number or operator 
        else {
            // Console log statement error message
            console.log(`Error: Invalid token '${token}'`);
            return;
        }
    }

    // Only one number as answer
    if (stack.length === 1) {
        // Console log statement the output
        console.log("\nPostfix evaluation result:", stack.pop());
    } 
    // More than 1 number present in output
    else {
        // Console log statement error message
        console.log("Error: Invalid postfix expression. Stack:", stack);
    }
}

// Menu for the sorting algos
function Menu_Sort(question, back_menu, algo_name, sort_algo) {
    // Shows the menu 
    function options_ask() {
        // Console log statements for the menu options
        console.log("\n============================================");
        console.log(`        ${algo_name} Sort Postfix Options`);
        console.log("============================================\n");
        console.log("1. Detailed Output (Sorting + Symbol Lookup)");
        console.log("2. Final Output");
        console.log("3. Back to Menu\n");

        // Question to ask the user to input option 1 to 3
        question.question("Choose an option (1-3): ", (option) => {
            // If the user input option 3
            if (option === "3") {
                // Return back to menu
                back_menu();
                return;
            }

            // If the user input is not 1,2, or 3
            if (option !== "1" && option !== "2") {
                // Console log statement error message
                console.log("Invalid choice. Please enter 1, 2, or 3.\n");
                // Ask the user to input again
                options_ask();
                return;
            }

            // If the user select 1, show the details
            const sorting_show = option === "1";

            // Question to ask user to input the postfix expression
            question.question("Enter space-separated postfix expression (e.g. 2 3 1 * + 9 -): ", (input) => {
                // If got spaces in input
                if (!input.includes(" ")) {
                    // Console log statement error message to input without spaces
                    console.log("Error: Please enter a space-separated postfix expression.");
                    // Return back to menu
                    back_menu();
                    return;
                }

                // Break the input into tokens
                const tokens = input.trim().split(/\s+/);
                // Evaluate the expressions
                Evaluation_Postfix(tokens, sorting_show, sort_algo);
                // Return back to menu
                back_menu();
            });
        });
    }

    // Ask the user input
    options_ask();
}

// Exported functions to use in main.js
module.exports = {
    // Bubble sort
    bubblesort: (question, back_menu) => Menu_Sort(question, back_menu, "Bubble", bubble_sort),
    // Insertion sort
    insertionsort: (question, back_menu) => Menu_Sort(question, back_menu, "Insertion", insertion_sort),
    // Merge sort
    mergesort: (question, back_menu) => Menu_Sort(question, back_menu, "Merge", merge_sort),
    // quick sort
    quicksort: (question, back_menu) => Menu_Sort(question, back_menu, "Quick", quick_sort),
    // selection sort
    selectionsort: (question, back_menu) => Menu_Sort(question, back_menu, "Selection", selection_sort),
};
