// Name: Subathra Sundarbabu
// Student id: 10263704
// Module code: CM2035
// Module name: Algorithms & Data Structures II
// Description: contains the main menu of the program for the user
// Date: 22 June 2025

// Readline package for the user input
const readline = require('readline');

// Input of the Inorder Transversal javascript file
const Inorder_transversal = require('./Symbol_table/Inorder_transveral');

// Input of the Binary Search javascript file
const Binary_search = require('./Symbol_table/Binary_search');

// Input of the Direct Addressing javascript file
const direct_addressing = require('./Symbol_table/direct_addressing');

// Input of the Hash Table javascript file
const hashtable = require('./Symbol_table/hashtable');

// Input of the arithmetic operations file
const { bubblesort, insertionsort, mergesort, quicksort, selectionsort} = require('./Arithmetic_operations/Arithmetic');

// Interface for reading input adn writing output
const question = readline.createInterface({
    input: process.stdin, // Input
    output: process.stdout // Output
});

// Function for the main menu
function Main_Menu() {
    // Console log statements for the different options for the user to choose
    console.log("\n============================================");
    console.log("        Welcome to PostFix Calculator!");
    console.log("============================================\n");
    console.log("1. Arithmetic_operations");
    console.log("2. Symbol_table");
    console.log("3. Exit\n");
    // Question for the user to enter their input
    question.question("Enter option (1-3): ", Menu_handle);
}

// Different case options for the user input
function Menu_handle(option) {
    // Trim option for the user input incase the user types any white spaces in their input
    switch (option.trim()) {
        // Case 1 shows the arithmetic menu for the user
        case '1':
            Arithmetic_Menu();
            break;
        // Case 2 shows the symbol table menu
        case '2':
            SymbolTable_Menu();
            break;
        // Case 3 exits the program
        case '3':
            console.log("Exiting program. Goodbye!");
            question.close();
            break;
        // Console log statement if the user inputs invalid option and show menu again for the user to choose again
        default:
            console.log("Invalid option. Please enter 1, 2, or 3.");
            Main_Menu();
    }
}

// Menu for Arithmetic Operations
function Arithmetic_Menu() {
    // Console log statements for arithmetic operations menu
    console.log("\n============================================");
    console.log("          Arithmetic Operations Menu          ");
    console.log("============================================\n");
    console.log("1. Bubble Sort");
    console.log("2. Insertion Sort");
    console.log("3. Merge Sort");
    console.log("4. Quick Sort");
    console.log("5. Selection Sort");
    console.log("6. Back to Main Menu\n");
    // Question for the user to input option 1 to 6
    question.question("Choose an option (1-6): ", Arithmetic_handle);
}

// Different case options for the user input
function Arithmetic_handle(option) {
    // Trim option for the user input incase the user types any white spaces in their input
    switch (option.trim()) {
        // Case 1 goes to the bubble sort menu options
        case '1':
            bubblesort(question, Arithmetic_Menu);
            return;
        // Case 2 goes to the insertion sort menu options
        case '2':
            insertionsort(question, Arithmetic_Menu);
            return;
        // Case 3 goes to the merge sort menu options
        case '3':
            mergesort(question, Arithmetic_Menu);
            return;
        // Case 4 goes to the quick sort menu options
        case '4':
            quicksort(question,Arithmetic_Menu);
            return;
        // Case 5 goes to the selection sort menu options
        case '5':
            selectionsort(question,Arithmetic_Menu);
            return;
        // Case 6 goes back to the main menu options
        case '6':
            Main_Menu();
            return;
        // Console log statement if the user input invalid options
        default:
            console.log("Invalid option. Please choose between 1 and 6.");
    }
    // Loop back to the arithmetic menu
    Arithmetic_Menu();
}

// Menu for Symbol Table
function SymbolTable_Menu() {
    // Console log statements for the symbol table menu
    console.log("\n============================================");
    console.log("              Symbol Table Menu               ");
    console.log("============================================\n");
    console.log("1. Inorder Transversal");
    console.log("2. Binary Search");
    console.log("3. Direct Addressing");
    console.log("4. Hash Table");
    console.log("5. Back to Main Menu\n");
    // Question for the user to input option 1 to 5
    question.question("Choose an option (1-5): ", SymbolTable_handle);
}

// Different case options for the user input
function SymbolTable_handle(option) {
    // Trim option for the user input incase the user types any white spaces in their input
    switch (option.trim()) {
        // Case 1 goes to the inorder transversal menu options
        case '1':
            Inorder_transversal(question, SymbolTable_Menu);
            return;
        // Case 2 goes to the binary search menu options
        case '2':
            Binary_search(question, SymbolTable_Menu);
            return;
        // Case 3 goes to the direct addressing menu options
        case '3':
            direct_addressing(question,SymbolTable_Menu);
            return;
        // Case 4 goes to the hashtable menu options
        case '4':
            hashtable(question, SymbolTable_Menu);
            return;
        // Case 5 go back to the main menu options
        case '5':
            Main_Menu();
            return;
        // Console log statement if the user input invalid options between 1 to 5
        default:
            console.log("Invalid option. Please choose between 1 and 5.");
    }
    // Loop back to the symbol table menu
    SymbolTable_Menu();
}

// Start the application
Main_Menu();
