// Program 5 : Hash table

// Name: Subathra Sundarbabu
// Student id: 10263704
// Module code: CM2035
// Module name: Algorithms & Data Structures II
// Description: Hash table algorithm on symbol table
// Date: 22 June 2025

// Hash table
let symbolTable = {};

// To check if the operator is valid
function operator_valid(token) {
    // Only these operators are valid
    return ['+', '-', '*', '/', '='].includes(token);
}

// To check if the variable is valid
function variable_valid(token) {
    // Only A - Z is valid
    return token.length === 1 && token >= 'A' && token <= 'Z';
}

// Insert variable and value
function variable_insert(key, value) {
    // Add or update the variable
    symbolTable[key] = value;
}

// Seach variable and value
function variable_search(key) {
    // Check if the symbol table has the key
    if (symbolTable.hasOwnProperty(key)) {
        // If the key exists, return value
        return symbolTable[key];
    } else {
        // Doesn't exist, return null
        return null;
    }
}

// Delete variable and value
function variable_delete(key) {
    // Only delete if exist
    if (symbolTable.hasOwnProperty(key)) {
        // Remove key value pair from the tabl
        delete symbolTable[key];
    }
}

function insertion_sort(array) {
    // For loop, start from the second number
    for (let i = 1; i < array.length; i++) {
        // Store the current number
        let key = array[i];

        // Compare with the number before it
        let j = i - 1;

        // Move numbers which are bigger than the key
        while (j >= 0 && array[j] > key) {
            // Move the bigger number to the right
            array[j + 1] = array[j];
            // Move to the previous number
            j = j - 1;
        }
        // Put the key at the sorted position
        array[j + 1] = key;
    }
    // Return the sorted array
    return array;
}

// Display the sorted symbol table
function symbol_table_sorted() {
    // Get variable names from the symbol table
    const keys = Object.keys(symbolTable);
    // If there are no keys
    if (keys.length === 0) {
        // console log statement. Table is empty
        console.log("Symbol table is empty.");
        return;
    }

    // Sort the keys using insertion sort
    const sortedKeys = insertion_sort(keys);

    // Console log statement 
    console.log("Symbol Table (Sorted by variable name):");
    
    // For loop to sort keys
    for (const key of sortedKeys) {
        // Console log statement to display variable with value
        console.log(`${key} = ${symbolTable[key]}`);
    }
}

// Postfix Evaluation
function evaluate_postfix(expression) {
    // Split input by space
    const tokens = expression.trim().split(' ');
    // Stack to hold the variables
    const stack = [];

    // Check if the expression contains 1 token and variable is valid
    if (tokens.length === 1 && variable_valid(tokens[0])) {
        // Get the value from the symbol table
        const value = variable_search(tokens[0]);

        // If variable is not found
        if (value === null) {
            // Console log statement error message
            console.log(`Error: Variable '${tokens[0]}' not found in symbol table.`);
            // Returns error
            return [];
        } 
        // If variable exists
        else {
            // Return as an array
            return [value];
        }
    }

    // Loop through each token
    for (const token of tokens) {
        // If token is not null
        if (!isNaN(token)) {
            // Push number to stack
            stack.push(Number(token));
        } 
        // If token is a variable
        else if (variable_valid(token)) {
            // Push variable to stack
            stack.push(token);
        } 
        // If token is a operator
        else if (operator_valid(token)) {
            // If token equal to =
            if (token === '=') {
                // If stack length is less than 2
                if (stack.length < 2) {
                    // Console log statement error message
                    console.log("Error: '=' operator requires a variable and a value.");
                    // return error
                    return [];
                }

                // pop value to assign
                const value = stack.pop();
                // pop variable to assign
                const variable = stack.pop();

                // if variable name is not valid
                if (!variable_valid(variable)) {
                    // Console log statement error message
                    console.log("Error: Only uppercase variable names A–Z are accepted.");
                    // Return error
                    return [];
                }
                
                // If value is vaariable name
                if (typeof value === 'string') {
                    // Seach value
                    val = variable_search(value);
                } else {
                    // Use number
                    val = value;
                }
                // Store value in symbol table
                variable_insert(variable, val);
            } else {
                // if stack length is less then 2
                if (stack.length < 2) {
                    // Console log statement error message
                    console.log(`Error: '${token}' operator requires two operands.`);
                    // return error
                    return [];
                }
                // Pop right operand
                const b_value = stack.pop();
                // Pop left operand
                const a_value = stack.pop();

                // If a is a string
                if (typeof a_value === 'string') {
                    // Search value in symbol table
                    value_A = variable_search(a_value);
                } else {
                    // if not a string, assign is directly
                    value_A = a_value;
                }

                // If b is a string
                if (typeof b_value === 'string') {
                    // Seach value in symbol table
                    value_B = variable_search(b_value);
                } else {
                    // If not a string, assign it directly
                    value_B = b_value;
                }

                // If a and b are null
                if (value_A === null || value_B === null) {
                    // Console log statement error message
                    console.log("Error: Undefined variable used.");
                    // return error
                    return [];
                }
                // Push result back to stack
                stack.push(math_evaluation(value_A, value_B, token));
            }
        } else {
            // Console log statament for invalid token
            console.log("Error: Invalid token or only uppercase variable names A–Z are allowed.");
            // Return error
            return [];
        }
    }

    // Return stack
    return stack;
}

// Math operations
function math_evaluation(a, b, operator) {
    switch (operator) {
        case '+': return a + b; // addition
        case '-': return a - b; // subtraction
        case '*': return a * b; // multiplication
        case '/': return a / b; //division
    }
}

// Menu for hash table
function hash_table(question, back_menu) {
    function menu_hashtable() {
        // Console log statements for the options
        console.log("\n============================================");
        console.log("      Hash Table Symbol Table Menu               ");
        console.log("============================================\n");
        console.log("1. Enter a postfix++ expression");
        console.log("2. View the symbol table");
        console.log("3. Search for variable in symbol table");
        console.log("4. Delete variable from symbol table");
        console.log("5. Back to Symbol Table Menu\n");
        // Question for the user for the input
        question.question("Enter option (1-5): ", option_handle);
    }

    // Handle the options
    function option_handle(option) {
        // Trim any spaces
        switch (option.trim()) {
            // Case 1
            case '1':
                // Console log statement
                console.log("Enter a postfix++ expression (type 'menu' to return):");
                // Input mode
                input_mode();
                break;
            // Case 2
            case '2':
                // Print the symbol table
                symbol_table_sorted();
                // show the menu again
                menu_hashtable();
                break;
            // Case 3
            case '3':
                // Question for the user to search a variable
                question.question("Search variable (A–Z): ", (input) => {
                    // Trim any spaces
                    const variable = input.trim();
                    // If variable is not valid
                    if (!variable_valid(variable)) {
                        // Console log statement error message
                        console.log("Error: Only uppercase variable names A–Z are accepted.");
                    } 
                    // If variable is valid
                    else {
                        // search the value
                        const value = variable_search(variable);
                        // If value not found
                        if (value === null) {
                            // Console log statement
                            console.log(`Variable '${variable}' not found in symbol table.`);
                        } 
                        // Else if the value is found
                        else {
                            // Console log statement
                            console.log(`Variable '${variable}' has value: ${value}`);
                        }
                    }
                    // Show the menu
                    menu_hashtable();
                });
                break;
            // case 4
            case '4':
                // Question for user input to delete variable
                question.question("Delete Variable (A–Z): ", (input) => {
                // Trim any spaces
                const variable = input.trim();
                // If variable is not valid
                if (!variable_valid(variable)) {
                    // Console log the error message
                    console.log("Error: Only uppercase variable names A–Z are accepted.");
                } 
                // Else if the variable is valid
                else {
                    // Search for the value
                    const value = variable_search(variable);
                    // If value is not found
                    if (value === null) {
                        // Console log statement
                        console.log(`Variable '${variable}' not found in symbol table.`);
                    } 
                    // If the value is found
                    else {
                        // delete the variable from symbol table
                        variable_delete(variable);
                        // Console log statement
                        console.log(`Variable '${variable}' deleted from symbol table.`);
                    }
                }

                // Show the menu
                menu_hashtable();
            });
            break;
            // Case 5
            case '5':
                // Back to symbol table menu
                back_menu();
                break;
            default:
                // Console log statement for invalid option
                console.log("Invalid option. Please enter 1-5.");
                // Show menu again
                menu_hashtable();
        }
    }

    // Allow multiple inputs from the user
    function input_mode() {
        // show > as starting the console
        question.question('> ', (line) => {
            // if the user types menu
            if (line.trim().toLowerCase() === 'menu') {
                // Go back to the menu
                menu_hashtable();
                return;
            }
            // Evaluate the postfix expression
            const result = evaluate_postfix(line);
            // Console log the result
            console.log("Result:", result);
            // Ask for the next input
            input_mode();
        });
    }

    // Start the menu
    menu_hashtable();
}

// Export function to use in main.js
module.exports = hash_table;