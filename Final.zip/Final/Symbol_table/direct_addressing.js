// Program 4 : Direct addressing

// Name: Subathra Sundarbabu
// Student id: 10263704
// Module code: CM2035
// Module name: Algorithms & Data Structures II
// Description: Direct addressing algorithm on symbol table
// Date: 22 June 2025

// Table for variables A-Z
let symbolTable = new Array(26).fill(null);

// To check if the operator is valid
function operator_valid(token) {
    // Only these operators are valid
    return ['+', '-', '*', '/', '='].includes(token);
}

// To check if the variable is valid
function variable_valid(token) {
    // Only A -Z is valid
    return token.length === 1 && token >= 'A' && token <= 'Z';
}

// Convert variable to an index
function variable_to_index(variable) {
    // Return the index number
    return variable.charCodeAt(0) - 'A'.charCodeAt(0);
}

// Insert variable into symbol table
function variable_insert(key, value) {
    // Get index from variable name
    const index = variable_to_index(key);
    // Store the value at the index
    symbolTable[index] = value;
}

// Search variable in symbol table
function variable_search(key) {
    // Get the index for the variable
    const index = variable_to_index(key);

    // if the symbol table has value at index
    if (symbolTable[index] !== null) {
        // Return the value if exists
        return symbolTable[index];
    } else {
        // Return null if not exist
        return null;
    }
}

// Delete variable in symbol table
function variable_delete(key) {
    // Get index for the variable
    const index = variable_to_index(key);
    // Set the index to null
    symbolTable[index] = null;
}

// Print symbol table
function symbol_table() {
    // Check if symbol table is empty
    let empty = true;
    // console log statement
    console.log("Symbol Table:");
    // Go thorugh all indexs
    for (let i = 0; i < 26; i++) {
        // If value exixts at index
        if (symbolTable[i] !== null) {
            // Convert index back to variable name
            const variable = String.fromCharCode(i + 'A'.charCodeAt(0));
            // Print variable and the value
            console.log(`${variable} = ${symbolTable[i]}`);
            // Mark table as not empty
            empty = false;
        }
    }
    // If emtpy
    if (empty) {
        // Console log statement
        console.log("Symbol table is empty.");
    }
}

// Postfix Evaluation
function evaluate_postfix(expression) {
    // Split input by space
    const tokens = expression.trim().split(' ');

    // Stack to hold the variables
    const stack = [];

    // Loop through each token
    for (const token of tokens) {
        // If token is not null
        if (!isNaN(token)) {
            // Push number to stack
            stack.push(Number(token));
        } 
        // If token is a variable
        else if (variable_valid(token)) {
            // Push variable to stack
            stack.push(token);
        } 
        // If token is a operator
        else if (operator_valid(token)) {
            // If token equal to =
            if (token === '=') {
                // if stack length is less than 2
                if (stack.length < 2) {
                    // Console log statemnet error message
                    console.log("Error: '=' operator requires a variable and a value.");
                    // return error
                    return [];
                }

                // pop value to assign
                const value = stack.pop();
                // pop variable to assign
                const variable = stack.pop();

                // if variable name is not valid
                if (!variable_valid(variable)) {
                    // Console log statement error message
                    console.log("Error: Only uppercase variable names A–Z are accepted.");
                    // Return error
                    return [];
                }
                
                // If value is vaariable name
                if (typeof value === 'string') {
                    // Seach value
                    val = variable_search(value);
                } else {
                    // Use number
                    val = value;
                }
                // Store value in symbol table
                variable_insert(variable, val);
            } else {
                // if stack length is less than 2
                if (stack.length < 2) {
                    // Console log statement error message
                    console.log(`Error: '${token}' operator requires two operands.`);
                    // Return error
                    return [];
                }

                // Pop right operand
                const b_value = stack.pop();
                // Pop left operand
                const a_value = stack.pop();
                // If a is a string
                if (typeof a_value === 'string') {
                    // Search value in symbol table
                    value_A = variable_search(a_value);
                } else {
                    // if not a string, assign is directly
                    value_A = a_value;
                }

                // If b is a string
                if (typeof b_value === 'string') {
                    // Seach value in symbol table
                    value_B = variable_search(b_value);
                } else {
                    // If not a string, assign it directly
                    value_B = b_value;
                }

                // If a and b are null
                if (value_A === null || value_B === null) {
                    // Console log statement error message
                    console.log("Error: Undefined variable used.");
                    // return error
                    return [];
                }
                // Push result back to stack
                stack.push(math_evaluation(value_A, value_B, token));
            }
        } else {
            // Console log statement for invalid token
            console.log("Error: Invalid token or only uppercase variable names A–Z are allowed.");
            // Return error
            return [];
        }
    }

    // Return stack
    return stack;
}

// Math operations
function math_evaluation(a, b, operator) {
    switch (operator) {
        case '+': return a + b; // addition
        case '-': return a - b; // subtraction
        case '*': return a * b; // multiplication
        case '/': return a / b; // division
    }
}

// Menu for direct addressing
function direct_addressing(question, back_menu){
        function menu_directaddressing() {
        // Console log statements for the options
        console.log("\n============================================");
        console.log("      Direct Addressing Symbol Table Menu     ");
        console.log("============================================\n");
        console.log("1. Enter a postfix++ expression");
        console.log("2. View the symbol table");
        console.log("3. Search for variable in symbol table");
        console.log("4. Delete variable from symbol table");
        console.log("5. Back to Symbol Table Menu\n");
        // Question for the user for the input
        question.question("Enter option (1-5): ", option_handle);
    }

    // Handle the options
    function option_handle(option) {
        // Trim any spaces
        switch (option.trim()) {
            // Case 1
            case '1':
                // Console log statement
                console.log("Enter a postfix++ expression (type 'menu' to return):");
                // Input mode
                input_mode();
                break;
            // Case 2
            case '2':
                // Print the symbol table
                symbol_table();
                // show the menu again
                menu_directaddressing();
                break;
            // Case 3
            case '3':
                // Question for the user to search a variable
                question.question("Search variable (A–Z): ", (input) => {
                // Trim any spaces
                const variable = input.trim();
                // If variable is not valid
                if (!variable_valid(variable)) {
                    // Console log statement error message
                    console.log("Error: Only uppercase variable names A–Z are accepted.");
                } 
                // If variable is valid
                else {
                    // Search the value
                    const value = variable_search(variable);
                    // If value not found
                    if (value === null) {
                        // Console log statement
                        console.log(`Variable '${variable}' not found in symbol table.`);
                    } 
                    // Else if the value is found
                    else {
                        // Console log statement
                        console.log(`Variable '${variable}' has value: ${value}`);
                    }
                }
                // Show the menu
                menu_directaddressing();
                });
                break;
            // Case 4
            case '4':
                // Question for user input to delete variable
                question.question("Delete Variable (A–Z): ", (input) => {
                    // Trim any spaces
                    const variable = input.trim().toUpperCase();
                    // If variable is not valid
                    if (!variable_valid(variable)) {
                        // Console log the error message
                        console.log("Error: Only single uppercase variable names A–Z are accepted.");
                    } 
                    // Else if the variable is valid
                    else {
                        // search for the value
                        const index = variable_to_index(variable);
                        // If value is not found
                        if (symbolTable[index] === null) {
                            // Console log statement
                            console.log(`Variable '${variable}' not found in symbol table.`);
                        } 
                        // If the value is fonud
                        else {
                            // delete variable from the symbol table
                            variable_delete(variable);
                            // Console log statement
                            console.log(`Variable '${variable}' deleted from symbol table.`);
                        }
                    }
                    // Show the menu
                    menu_directaddressing();
                });
                break;
            // Case 5
            case '5':
                // Back to symbol table menu
                back_menu();
                break;
            default:
                // Console log statement for invalid options
                console.log("Invalid option. Please enter 1-5.");
                // Show menu again
                menu_directaddressing();
        }
    }

    // Allow multiple inputs from the user
    function input_mode() {
        // show > as starting the console
        question.question('> ', (line) => {
            // if the user types menu
            if (line.trim().toLowerCase() === 'menu') {
                // Go back to the menu
                menu_directaddressing();
                return;
            }
            // Evaluate the postfix expression
            const result = evaluate_postfix(line);
            // Console log the result
            console.log("Result:", result);
            // Ask for the next input
            input_mode();
        });
    }

    // Start the menu
    menu_directaddressing();
}

// Export function to use in main.js
module.exports = direct_addressing;