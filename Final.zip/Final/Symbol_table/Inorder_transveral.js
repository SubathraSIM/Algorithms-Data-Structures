// Program 2 : Inorder_transversal

// Name: Subathra Sundarbabu
// Student id: 10263704
// Module code: CM2035
// Module name: Algorithms & Data Structures II
// Description: Shows the infix parantheses for the user input postfix evaluation
// Date: 22 June 2025

// Create Node 
function node_creating(value) {
    return {
        // Node value
        value: value,
        // left child
        left: null,
        // right child
        right: null
    };
}

// To check is the operator is valid
function operator_valid(token) {
    // Only these operators are valid
    return ['+', '-', '*', '/', '='].includes(token);
}

// To check is the variable is valid
function variable_valid(token) {
    // Only A - Z is valid
    return token.length === 1 && token >= 'A' && token <= 'Z';
}

// Expression Tree
function tree_expression(tokens) {
    // Stack to store nodes
    const stack = [];

    // Loop thorugh each variable
    for (const token of tokens) {
        // If token is not null and is valid variable
        if (!isNaN(token) || variable_valid(token)) {
            // Push to the stack
            stack.push(node_creating(token));
        } 
        // If it is a operator
        else if (operator_valid(token)) {
            // Pop 2 nodes from the stack
            const right = stack.pop();
            const left = stack.pop();

            // Not enough operands
            if (!left || !right) {
                // Console log statement error message
                console.log(`Error: Not enough operands for operator '${token}'.`);
                
                // Return null
                return null;
            }

            // New operator node
            const node = node_creating(token);
            // Left node
            node.left = left;
            // Right node
            node.right = right;
            // Push new node to the stack
            stack.push(node);
        } 
        // If the token not valid
        else {
            // Console log statement error message
            console.log(`Error: Invalid token '${token}'.`);
            return null;
        }
    }
    // If one node is left
    if (stack.length === 1) {
        // return stack at index 0
        return stack[0];
    } else {
        // else return null
        return null;
    }
}

// Infix expression with parentheses
function infix_parentheses(node) {
    // Empty string if the node is null
    if (!node) return '';

    // Return the value if the no left and right node
    if (!node.left && !node.right) {
        return node.value;
    }

    // Process left and wrap with parentheses
    const left = infix_parentheses(node.left);

    // Process right and wrap with parentheses
    const right = infix_parentheses(node.right);

    // Return the combined string
    return `(${left}${node.value}${right})`;
}

// Expand postfix expression
function postfix_expression(expression) {
    // split tokens by space
    const tokens = expression.trim().split(/\s+/);
    // build expression tree
    const root_tree = tree_expression(tokens);

    // If tree is invalid
    if (!root_tree) {
        // Console log statement error message
        console.log("Invalid postfix expression.");
        return;
    }

    // Index expression
    const infix = infix_parentheses(root_tree);
    // Console log statement with the output
    console.log("Expanded (Infix with parentheses):", infix);
}

// Menu for inorder transversal
function inorder_traversal(question, back_menu) {
    // Menu options
    function menu_inorder() {
        // Console log statements for the options
        console.log("\n============================================");
        console.log("        Inorder Traversal Expansion Menu       ");
        console.log("============================================\n");
        console.log("1. Enter a postfix expression to expand");
        console.log("2. Back to Symbol Table Menu\n");
        // Question for the user for the input
        question.question("Enter option (1-2): ", option_handle);
    }

    // Handle the options
    function option_handle(option) {
        // Trim any spaces
        switch (option.trim()) {
            // Case 1
            case '1':
                // Consoloe log statement
                console.log("Enter a postfix expression (type 'menu' to return):");
                // Input mode
                input_mode();
                break;
            // Case 2
            case '2':
                // Back to symbol table menu
                back_menu();
                break;
            default:
                // Console log statement for invalid option
                console.log("Invalid option. Please enter 1 or 2.");
                // show menu again
                menu_inorder();
        }
    }

    // Allow multiple inputs from the user
    function input_mode() {
        // show > as starting the console
        question.question('> ', (line) => {
            // If the user types menu
            if (line.trim().toLowerCase() === 'menu') {
                // Go back to the menu
                menu_inorder();
                return;
            }
            // Show the infix form 
            postfix_expression(line);

            // ask for the next input
            input_mode();
        });
    }

    // Start the menu
    menu_inorder();
}

// Export function to use in main.js
module.exports = inorder_traversal;
