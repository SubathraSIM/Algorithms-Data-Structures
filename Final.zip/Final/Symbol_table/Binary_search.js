// Program 3 : Binary Search

// Name: Subathra Sundarbabu
// Student id: 10263704
// Module code: CM2035
// Module name: Algorithms & Data Structures II
// Description: Binary Search algorithm on symbol table
// Date: 22 June 2025

// Create Node 
function node_creating(key, value) {
    return {
        // Key value
        key: key,
        // Node value
        value: value,
        // left child
        left: null,
        // right child
        right: null
    };
}

// root of binary search
let root = null;

// To check if the operator is valid
function operator_valid(token) {
    // Only these operators are valid
    return ['+', '-', '*', '/', '='].includes(token);
}

// To check if the variable is valid
function variable_valid(token) {
    // Only A - Z is valid
    return token.length === 1 && token >= 'A' && token <= 'Z';
}

// Insert variable and value 
function variable_insert(key, value) {
    root = insert_node(root, key, value);
}

// Recursive function to insert a node
function insert_node(node, key, value) {
    // If no node, create one
    if (node === null) return node_creating(key, value);
    // Insert to the left if smaller
    if (key < node.key) node.left = insert_node(node.left, key, value);
    // Insert to the right if bigger
    else if (key > node.key) node.right = insert_node(node.right, key, value);
    // If key exits, update value
    else node.value = value;
    return node;
}

// Search for variable by key
function variable_search(key) {
    return search_node(root, key);
}

// Recursive function to search for a key
function search_node(node, key) {
    // Not found return null
    if (node === null) return null;
    // If exists, return the value
    if (key === node.key) return node.value;
    // Search left
    if (key < node.key) return search_node(node.left, key);
    // Search right
    return search_node(node.right, key);
}

// delete variable by key
function variable_delete(key) {
    root = delete_node(root, key);
}

// Recursive function to delete node
function delete_node(node, key) {
    // If tree is empty, return null
    if (node === null) return null;
    // Search left
    if (key < node.key) node.left = delete_node(node.left, key);
    // Search right
    else if (key > node.key) node.right = delete_node(node.right, key);
    // Found the node to delete
    else {
        // If only right 
        if (node.left === null) return node.right;
        // If only left
        if (node.right === null) return node.left;
        // Get the smallet node in right
        let minimum_node = minimum_find(node.right);
        // Replace current node with minimum_node key
        node.key = minimum_node.key;
        // Replace the value
        node.value = minimum_node.value;
        // Delete duplicate
        node.right = delete_node(node.right, minimum_node.key);
    }
    // return node
    return node;
}

// Find minimum node
function minimum_find(node) {
    // Left till end
    while (node.left !== null) node = node.left;
    return node;
}

// Print the symbol table
function symbol_table() {
    // If no value in symbol table
    if (root === null) {
        // Console log statement 
        console.log("Symbol table is empty.");
    } 
    // If something in symbol table
    else {
        // Console log statement
        console.log("Symbol Table:");
        // Order the symbol table values
        sort_order(root);
    }
}

// Recusrive function to print key-value in sorted order
function sort_order(node) {
    // If node is not null
    if (node !== null) {
        // Go left
        sort_order(node.left);
        // Print current node
        console.log(`${node.key} = ${node.value}`);
        // Go right
        sort_order(node.right);
    }
}

// Postfix Evaluation
function evaluate_postfix(expression) {
    // Split input by space
    const tokens = expression.trim().split(' ');
    // Stack to hold the variables
    const stack = [];

    // Loop through each token
    for (const token of tokens) {
        // If token is not null
        if (!isNaN(token)) {
            // Push number to stack
            stack.push(Number(token));
        } 
        // If token is a variable
        else if (variable_valid(token)) {
            // Push variable to stack
            stack.push(token);
        } 
        // If token is a operator
        else if (operator_valid(token)) {
            // if token equal to =
            if (token === '=') {
                // if stack length is less than 2
                if (stack.length < 2) {
                    // Console log statement error message
                    console.log("Error: '=' operator requires a variable and a value.");
                    // Return error
                    return [];
                }
                
                // pop value to assign
                const value = stack.pop();
                // pop variale to assign
                const variable = stack.pop();
                
                // if variable name is not valid
                if (!variable_valid(variable)) {
                    // Consoloe log statement error message
                    console.log("Error: Only uppercase variable names A–Z are accepted.");
                    // Return error
                    return [];
                }
    
                // If value is vaariable name
                if (typeof value === 'string') {
                    // Seach value
                    val = variable_search(value);
                } else {
                    // Use number
                    val = value;
                }
                // Store value in symbol table
                variable_insert(variable, val);
            } else {
                // if stack length is less than 2
                if (stack.length < 2) {
                    // Console log statement error message
                    console.log(`Error: '${token}' operator requires two operands.`);
                    // Return error
                    return [];
                }

                // Pop right operand
                const b_value = stack.pop();
                // Pop left operand
                const a_value = stack.pop();

                // If a is a string
                if (typeof a_value === 'string') {
                    // Search value in symbol table
                    value_A = variable_search(a_value);
                } else {
                    // if not a string, assign is directly
                    value_A = a_value;
                }

                // If b is a string
                if (typeof b_value === 'string') {
                    // Seach value in symbol table
                    value_B = variable_search(b_value);
                } else {
                    // If not a string, assign it directly
                    value_B = b_value;
                }

                // If a and b are null
                if (value_A === null || value_B === null) {
                    // Console log statement error message
                    console.log("Error: Undefined variable used.");
                    // return error
                    return [];
                }
                // Push result back to stack
                stack.push(math_evaluation(value_A, value_B, token));
            }
        } else {
            // Console log statament for invalid token
            console.log("Error: Invalid token or only uppercase variable names A–Z are allowed.");
            // Return error
            return [];
        }
    }

    // Return stack
    return stack;
}

// Math operations
function math_evaluation(a, b, operator) {
    switch (operator) {
        case '+': return a + b; // addition
        case '-': return a - b; // subtraction
        case '*': return a * b; // multiplication
        case '/': return a / b; //division
    }
}

// Menu for binary search
function binary_search(question, back_menu) {
    function menu_binarysearch() {
        // Console log statements for the options
        console.log("\n============================================");
        console.log("      Binary Search Symbol Table Menu               ");
        console.log("============================================\n");
        console.log("1. Enter a postfix++ expression");
        console.log("2. View the symbol table");
        console.log("3. Search for variable in symbol table");
        console.log("4. Delete variable from symbol table");
        console.log("5. Back to Symbol Table Menu\n");
        // Question for the user for the input
        question.question("Enter option (1-5): ", option_handle);
    }

    // Handle the options
    function option_handle(option) {
        // Trim any spaces
        switch (option.trim()) {
            // Case 1
            case '1':
                // Console log statement
                console.log("Enter a postfix++ expression (type 'menu' to return):");
                // Input mode
                input_mode();
                break;
            // Case 2
            case '2':
                // Print the symbol table
                symbol_table();
                // show the menu again
                menu_binarysearch();
                break;
            // Case 3
            case '3':
                // Question for the user to search a variable
                question.question("Search variable (A–Z): ", (input) => {
                    // Trim any spaces
                    const variable = input.trim();
                    // If variable is not valid
                    if (!variable_valid(variable)) {
                        // Console log statement error message
                        console.log("Error: Only uppercase variable names A–Z are accepted.");
                    } 
                    // If variable is valid
                    else {
                        // search the value
                        const value = variable_search(variable);
                        // If value not found
                        if (value === null) {
                            // Console log statement
                            console.log(`Variable '${variable}' not found in symbol table.`);
                        } 
                        // Else if the value is found
                        else {
                            // Console log statement
                            console.log(`Variable '${variable}' has value: ${value}`);
                        }
                    }
                    // Show the menu
                    menu_binarysearch();
                });
                break;
            // Case 4
            case '4':
                // Question for user input to delete variable
                question.question("Delete Variable (A–Z): ", (input) => {
                    // Trim any spaces
                    const variable = input.trim();
                    // If variable is not valid
                    if (!variable_valid(variable)) {
                        // Console log the error message
                        console.log("Error: Only uppercase variable names A–Z are accepted.");
                    } 
                    // Else if the variable is valid
                    else {
                        // Search for the value
                        const value = variable_search(variable);
                        // If value is not found
                        if (value === null) {
                            // Console log statement
                            console.log(`Variable '${variable}' not found in symbol table.`);
                        } 
                        // If the value is found
                        else {
                            // delete the variable from symbol table
                            variable_delete(variable);
                            // Console log statement
                            console.log(`Variable '${variable}' deleted from symbol table.`);
                        }
                    }
                    // Show the menu
                    menu_binarysearch();
                });
                break;
            // Case 5
            case '5':
                // Back to symbol table menu
                back_menu();
                break;
            default:
                // Console log statement for invalid option
                console.log("Invalid option. Please enter 1-5.");
                // show menu again
                menu_binarysearch();
        }
    }

    // Allow multiple inputs from the user
    function input_mode() {
        // show > as starting the console
        question.question('> ', (line) => {
            // if the user types menu
            if (line.trim().toLowerCase() === 'menu') {
                // Go back to the menu
                menu_binarysearch();
                return;
            }
            // Evaluate the postfix expression
            const result = evaluate_postfix(line);
            // Console log the result
            console.log("Result:", result);
            // Ask for the next input
            input_mode();
        });
    }

    // Start the menu
    menu_binarysearch();
}

// Export function to use in main.js
module.exports = binary_search;
